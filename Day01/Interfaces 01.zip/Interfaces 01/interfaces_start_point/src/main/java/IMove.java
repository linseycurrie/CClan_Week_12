public interface IMove {

    public void move(int distance);


}
