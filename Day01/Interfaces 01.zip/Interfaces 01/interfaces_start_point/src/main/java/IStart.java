public interface IStart {

    public String start();
}
