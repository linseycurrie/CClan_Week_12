public interface IStop {

    public String stop();
}
