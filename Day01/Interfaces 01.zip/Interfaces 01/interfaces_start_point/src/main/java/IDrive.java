public interface IDrive extends IMove {

    public void steer();
}
